<?php
$host = 'localhost';        // Database host, change if necessary
$dbname = 'eblotterdatabase';       // Your database name
$username = 'root';         // Your database username
$password = '';             // Your database password (empty by default for localhost)

try {
    // Create a PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch (PDOException $e) {
    // Handle connection errors
    die("PDO connection failed: " . $e->getMessage());
}

$conn = new mysqli($host, $username, $password, $dbname);
?>