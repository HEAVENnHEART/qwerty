<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Blotter Public Portal</title>
    <link rel="stylesheet" href="CSS/index.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">Lawa Public Portal</div>
        <ul class="nav-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="#request">Request</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>

    <main>
        <section id="home" class="hero">
            <h1>Welcome to Lawa Management System</h1>
            <p>NAG KAON KANA LAV</p>
            <button class="cta-button">Learn More</button>
        </section>

        <section id="services">
            <h2>Our Services</h2>
            <p>POGI SI AERON</p>
        </section>

        <section id="about">
            <h2>About Us</h2>
            <p>MAS POGI SI AERON</p>
        </section>

        <section id="contact">
            <h2>Contact Us</h2>
            <p>SOBRANG POGI NI AERON</p>
        </section>

        <section id="request" class="request-section">
            <div class="request-container">
                <h2>Document Request Form</h2>
                <form class="request-form" action="process_request.php" method="POST">
                    <div class="form-group">
                        <label for="fullname">Full Name</label>
                        <input type="text" id="fullname" name="fullname" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Contact Number</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="document_type">Document Type</label>
                        <select id="document_type" name="document_type" required>
                            <option value="">Select Document Type</option>
                            <option value="barangay_clearance">Barangay Clearance</option>
                            <option value="indigency">Indigency</option>
                            <option value="business_permit">Business Permit</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="purpose">Purpose</label>
                        <textarea id="purpose" name="purpose" required></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">Submit Request</button>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 E-Blotter System. All rights reserved.</p>
    </footer>
</body>
</html>
