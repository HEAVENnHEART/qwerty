<?php
session_start(); // Start session to access logged-in user's info

// Include database connection
include('db.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect if not logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the new profile information from the form
    $user_id = $_SESSION['user_id'];
    $email = $_POST['email'];
    $username = $_POST['username'];

    // Update the user profile in the database
    $sql = "UPDATE users SET email = '$email', username = '$username' WHERE id = '$user_id'";

    if ($conn->query($sql) === TRUE) {
        header('Location: account.php'); // Redirect back to account page
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>