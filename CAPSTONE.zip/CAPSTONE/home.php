<?php
include 'db.php'; // Include the database connection

session_start(); // Start the session

// Check if the user is logged in (session variable exists)
if (!isset($_SESSION['user_id'])) {
    // If no session, redirect to login page
    header("Location: login.php");
    exit(); // Stop further execution
}

// Fetch the user's information based on the user_id stored in the session
$user_id = $_SESSION['user_id']; // Get the user ID from the session
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // Get user info
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Fetch available years from the records
try {
    $stmt = $pdo->prepare("SELECT DISTINCT year FROM records ORDER BY year DESC");
    $stmt->execute();
    $years = $stmt->fetchAll(PDO::FETCH_ASSOC); // Get all distinct years
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Default year is the most recent year if no filter is set
$selectedYear = isset($_GET['year']) ? $_GET['year'] : (isset($years[0]) ? $years[0]['year'] : date('Y'));

// Fetch case types and their counts for the selected year
try {
    $stmt = $pdo->prepare("
        SELECT case_type, COUNT(*) as count
        FROM records
        WHERE year = :selected_year
        GROUP BY case_type
    ");
    $stmt->bindParam(':selected_year', $selectedYear, PDO::PARAM_INT);
    $stmt->execute();
    $caseData = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Prepare data for the pie chart
$labels = [];
$data = [];
foreach ($caseData as $case) {
    $labels[] = $case['case_type'];
    $data[] = (int)$case['count'];
}

// Fetch case counts by month for the selected year
$stmt = $pdo->prepare("SELECT month, COUNT(*) as count FROM records WHERE year = :selected_year GROUP BY month");
$stmt->bindParam(':selected_year', $selectedYear, PDO::PARAM_INT);
$stmt->execute();
$monthData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prepare data for the month chart
$monthLabels = [];
$monthCounts = [];
foreach ($monthData as $month) {
    $monthLabels[] = $month['month'];
    $monthCounts[] = (int)$month['count'];
}

// Fetch gender data for the selected year
$stmt = $pdo->prepare("SELECT gender, COUNT(*) as count FROM records WHERE year = :selected_year GROUP BY gender");
$stmt->bindParam(':selected_year', $selectedYear, PDO::PARAM_INT);
$stmt->execute();
$genderData = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/home.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
</head>
<body>

<div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <a href="home.php">
                <img src="logo.png" alt="E-Blotter Logo" class="logo-image">
            </a>
        </div>

        <!-- Display the logged-in user's name in the sidebar -->
        <hr><br>
        <ul>
            <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
        </ul><br><hr><br>

        <ul>
    <li><a href="home.php">Home</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="form.php">Forms</a></li>
            <li><a href="record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document-request.php">Request</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="logout.php">Log Out</a></li>
</ul>

    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>Welcome to BMS!</h1>
        </div>

        <!-- Year Filter -->
        <form method="GET" action="home.php">
            <div class="year-filter">
                <label for="year">Select Year:</label>
                <select name="year" id="year" onchange="this.form.submit()">
                    <?php foreach ($years as $year) : ?>
                        <option value="<?= $year['year']; ?>" <?= $year['year'] == $selectedYear ? 'selected' : ''; ?>>
                            <?= $year['year']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>

        <br><div class="container">
        <br>
            <!-- Chart for Case Types -->
            <div class="chart-container">
                <canvas id="caseChart"></canvas>
            </div>
        </div><br>

        <div class="container">
            <!-- Case Type Data Table -->
            <div>
                <h2>Case Reported</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Case Type</th>
                            <th>Count</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($caseData as $case) : ?>
                            <tr>
                                <td><?= htmlspecialchars($case['case_type']); ?></td>
                                <td><?= htmlspecialchars($case['count']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Monthly Case Data Table -->
            <div>
                <h2>Monthly Case Report</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Case Count</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($monthData as $month) : ?>
                            <tr>
                                <td><?= htmlspecialchars($month['month']); ?></td>
                                <td><?= htmlspecialchars($month['count']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2024 E-Blotter System. All Rights Reserved.</p>
</div>

<script>
    const chartLabels = <?php echo json_encode($labels); ?>;
    const chartData = <?php echo json_encode($data); ?>;
</script>
<script src="JS/home.js"></script>

</body>
</html>