<?php
session_start(); // Start session to access logged-in user's info
// Include database connection
include('db.php');
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect if not logged in
    exit();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $current_password = $_POST['current-password'];
    $new_password = $_POST['new-password'];
    $confirm_password = $_POST['confirm-password'];
    // Fetch current password from database
    $sql = "SELECT password FROM users WHERE id = '$user_id'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();
    // Verify the current password
    if (password_verify($current_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            // Hash new password and update it in the database
            $new_hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
            $update_sql = "UPDATE users SET password = '$new_hashed_password' WHERE id = '$user_id'";

            if ($conn->query($update_sql) === TRUE) {
                header('Location: account.php'); // Redirect after successful password change
            } else {
                echo "Error updating password: " . $conn->error;
            }
        } else {
            echo "New passwords do not match.";
        }
    } else {
        echo "Incorrect current password.";
    }
}
?>