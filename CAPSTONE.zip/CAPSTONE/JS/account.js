function showEditForm() {
    document.getElementById('edit-profile-form').style.display = 'block';
}
function cancelEdit() {
    document.getElementById('edit-profile-form').style.display = 'none';
}
// Function to confirm submission of the Edit Profile form
function confirmSubmit1(event, message) {
    if (confirm(message)) {
        // If confirmed, submit the form
        event.target.closest('form').submit();
    }
}
// Function to confirm submission of the Change Password form
function confirmSubmit(event, message) {
    if (confirm(message)) {
        // If confirmed, submit the form
        event.target.closest('form').submit();
    }
}