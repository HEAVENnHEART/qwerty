<?php
include 'db.php';

// Start the session to access session variables
session_start();

$searchTerm = '';
$filter = 'all';  

// Get the search term and filter
if (isset($_GET['search'])) {
    $searchTerm = $_GET['search'];
}

if (isset($_GET['filter'])) {
    $filter = $_GET['filter'];
}

// Pagination Variables
$recordsPerPage = 7;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page, default is 1
$offset = ($page - 1) * $recordsPerPage; // Offset for SQL query

try {
    // Base SQL query with LIMIT and OFFSET
    $sql = "
    SELECT r.*, GROUP_CONCAT(ip.name ORDER BY ip.name ASC) AS involved_parties
    FROM records r
    LEFT JOIN involved_parties ip ON r.id = ip.record_id
    WHERE ";
    
    // Modify the query based on selected filter
    if ($filter === 'all') {    
        $sql .= "
            r.name LIKE :searchTerm 
            OR r.age LIKE :searchTerm
            OR r.gender LIKE :searchTerm
            OR r.relationship LIKE :searchTerm
            OR r.contact LIKE :searchTerm
            OR r.address LIKE :searchTerm
            OR r.case_type LIKE :searchTerm
            OR r.month LIKE :searchTerm
            OR ip.name LIKE :searchTerm
            OR position LIKE :searchTerm
        ";
    } else {
        if ($filter === 'involved_parties') {
            $sql .= "ip.name LIKE :searchTerm";
        } else {
            $sql .= "r.$filter LIKE :searchTerm";
        }
    }

    // Add LIMIT and OFFSET to the SQL query
    $sql .= " GROUP BY r.id ORDER BY r.created_at DESC LIMIT :limit OFFSET :offset";
    
    // Prepare and execute the SQL query with search term, limit, and offset
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':searchTerm', "%$searchTerm%");
    $stmt->bindValue(':limit', $recordsPerPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Pagination - total records query
    $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM records r LEFT JOIN involved_parties ip ON r.id = ip.record_id WHERE r.name LIKE :searchTerm OR r.age LIKE :searchTerm OR r.gender LIKE :searchTerm OR r.relationship LIKE :searchTerm OR r.contact LIKE :searchTerm OR r.address LIKE :searchTerm OR r.case_type LIKE :searchTerm OR r.month LIKE :searchTerm OR ip.name LIKE :searchTerm");
    $totalStmt->bindValue(':searchTerm', "%$searchTerm%");
    $totalStmt->execute();
    $totalRecords = $totalStmt->fetchColumn();

    // Calculate total pages
    $totalPages = ceil($totalRecords / $recordsPerPage);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Handle delete action
if (isset($_GET['delete'])) {
    $deleteId = $_GET['delete'];
    try {
        $deleteStmt = $pdo->prepare("DELETE FROM records WHERE id = :id");
        $deleteStmt->execute(['id' => $deleteId]);
        header("Location: individual-record.php"); // Refresh the page after deletion
        exit();
    } catch (PDOException $e) {
        echo "Error deleting record: " . $e->getMessage();
    }
}

// Handle status toggle action
if (isset($_GET['toggle_status'])) {
    $toggleId = $_GET['toggle_status'];
    try {
        // Fetch the current status to toggle it
        $statusStmt = $pdo->prepare("SELECT is_closed FROM records WHERE id = :id");
        $statusStmt->execute(['id' => $toggleId]);
        $currentStatus = $statusStmt->fetchColumn();
        
        // Toggle the status
        $newStatus = $currentStatus == 1 ? 0 : 1;
        
        $updateStmt = $pdo->prepare("UPDATE records SET is_closed = :status WHERE id = :id");
        $updateStmt->execute(['status' => $newStatus, 'id' => $toggleId]);
        header("Location: individual-record.php"); // Refresh the page after status toggle
        exit();
    } catch (PDOException $e) {
        echo "Error updating status: " . $e->getMessage();
    }
}

// Check if user session is set
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql_users = "SELECT * FROM users WHERE id = :user_id";  // Use parameterized query to prevent SQL injection
    $stmt_users = $pdo->prepare($sql_users);
    $stmt_users->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_users->execute();

    if ($stmt_users->rowCount() > 0) {
        $user = $stmt_users->fetch(PDO::FETCH_ASSOC); // Fetch the user as an associative array
    } else {
        echo "User not found.";
        exit(); // Stop execution if user is not found
    }
} else {
    echo "Session not started. Please log in.";
    exit(); // Stop execution if session is not found
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BLotter Record</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/individual-record.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="home.php">
                    <img src="logo.png" alt="E-Blotter Logo" class="logo-image">
                </a><br>
            </div>
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            <ul>
    <li><a href="home.php">Home</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="form.php">Forms</a></li>
            <li><a href="record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document-request.php">Request</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="logout.php">Log Out</a></li>
</ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Individual Record Table</h1>
            </div>
            <div class="container">
                <form method="GET" action="individual-record.php">
                    <div class="search-container">
                        <input type="text" name="search" value="<?= htmlspecialchars($searchTerm) ?>" placeholder="Search records..." class="search-bar">
                        <select name="filter" class="filter-dropdown">
                            <option value="name" <?= $filter == 'name' ? 'selected' : '' ?>>Name</option>
                            <option value="age" <?= $filter == 'age' ? 'selected' : '' ?>>Age</option>
                            <option value="gender" <?= $filter == 'gender' ? 'selected' : '' ?>>Gender</option>
                            <option value="relationship" <?= $filter == 'relationship' ? 'selected' : '' ?>>Relationship</option>
                            <option value="contact" <?= $filter == 'contact' ? 'selected' : '' ?>>Contact Number</option>
                            <option value="address" <?= $filter == 'address' ? 'selected' : '' ?>>Address</option>
                            <option value="case_type" <?= $filter == 'case_type' ? 'selected' : '' ?>>Case</option>
                            <option value="involved_parties" <?= $filter == 'involved_parties' ? 'selected' : '' ?>>Respondent</option>
                            <option value="position" <?= $filter == 'position' ? 'selected' : '' ?>>Official</option>
                        </select>
                        <button type="submit" class="search-button">Search</button>
                    </div>
                </form>

                <div id="records">
                    <?php if (empty($records)): ?>
                        <p>No records found matching your search criteria.</p>
                    <?php else: ?>
                        <table border="1" cellpadding="10" cellspacing="10">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Age</th>
                                    <th>Gender</th>
                                    <th>Relationship</th>
                                    <th>Contact Number</th>
                                    <th>Address</th>
                                    <th>Respondent</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Case</th>
                                    <th>Official</th>
                                    <th>Actions</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($records as $record): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($record['name']) ?></td>
                                        <td><?= htmlspecialchars($record['age']) ?></td>
                                        <td><?= htmlspecialchars($record['gender']) ?></td>
                                        <td><?= htmlspecialchars($record['relationship']) ?></td>
                                        <td><?= htmlspecialchars($record['contact']) ?></td>
                                        <td><?= htmlspecialchars($record['address']) ?></td>
                                        <td>
                                            <?php if (!empty($record['involved_parties'])): ?>
                                                <div class="parties-list">
                                                    <?= htmlspecialchars($record['involved_parties']) ?>
                                                </div>
                                            <?php else: ?>
                                                <p>No involved parties</p>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars($record['month']) ?>
                                            <?= htmlspecialchars($record['day']) ?>
                                            <?= htmlspecialchars($record['year']) ?>
                                        </td>
                                        <td><?= htmlspecialchars($record['time']) ?></td>
                                        <td><?= htmlspecialchars($record['case_type']) ?></td>
                                        <td style="font-style: italic;">
                                            <?= htmlspecialchars($record['position']) ?>
                                        </td>
                                        <td>
                                            <a href="view.php?id=<?= $record['id'] ?>" class="button">View</a>
                                            <a href="edit.php?id=<?= $record['id'] ?>" class="button">Edit</a>
                                            <a href="individual-record.php?delete=<?= $record['id'] ?>" class="button" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>
                                        </td>
                                        <td>
                                            <a href="individual-record.php?toggle_status=<?= $record['id'] ?>" class="button" 
                                               style="background-color: <?= isset($record['is_closed']) && $record['is_closed'] == 1 ? 'green' : 'red'; ?>;">
                                                <?= isset($record['is_closed']) && $record['is_closed'] == 1 ? 'Case Closed' : 'Case Open' ?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- Pagination Section -->
                <div class="pagination">
                    <!-- First Page Link -->
                    <?php if ($page > 1): ?>
                        <a href="individual-record.php?page=1&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>">First</a>
                    <?php else: ?>
                        <span class="disabled">First</span>
                    <?php endif; ?>

                    <!-- Previous Page Link -->
                    <?php if ($page > 1): ?>
                        <a href="individual-record.php?page=<?= $page - 1 ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>">Previous</a>
                    <?php else: ?>
                        <span class="disabled">Previous</span>
                    <?php endif; ?>

                    <!-- Current Page Info -->
                    <span>Page <?= $page ?> of <?= $totalPages ?></span>

                    <!-- Next Page Link -->
                    <?php if ($page < $totalPages): ?>
                        <a href="individual-record.php?page=<?= $page + 1 ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>">Next</a>
                    <?php else: ?>
                        <span class="disabled">Next</span>
                    <?php endif; ?>

                    <!-- Last Page Link -->
                    <?php if ($page < $totalPages): ?>
                        <a href="individual-record.php?page=<?= $totalPages ?>&search=<?= urlencode($searchTerm) ?>&filter=<?= $filter ?>">Last</a>
                    <?php else: ?>
                        <span class="disabled">Last</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2024 E-Blotter System. All rights reserved.</p>
        </div>
    </div>
</body>
</html>