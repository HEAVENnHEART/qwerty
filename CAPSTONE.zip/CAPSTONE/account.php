<?php
session_start(); // Start session to access logged-in user's info
// Include database connection
include('db.php');
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Redirect if not logged in
    exit();
}
// Fetch user data from database
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = '$user_id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/account.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
</head>
<body>
<div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <a href="home.php">
                <img src="logo.png" alt="E-Blotter Logo" class="logo-image">
            </a><br>
        </div>
        <hr><br><ul>
            <p class="username-display">Welcome, <?php echo htmlspecialchars($user['username']); ?>!</p>
        </ul><br><hr><br>
        <ul>
    <li><a href="home.php">Home</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="form.php">Forms</a></li>
            <li><a href="record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document-request.php">Request</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="logout.php">Log Out</a></li>
</ul>
    </div>
    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>My Account</h1>
        </div>
        <div class="container">
            <!-- Account Information Section -->
            <div class="account-info">
                <h2>My Profile</h2>
                <br>
                <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <br>
                <button onclick="showEditForm()">Edit Profile</button>
            </div>
            <!-- Edit Profile Form -->
            <div id="edit-profile-form" class="account-form" style="display:none;">
                <br><h2>Edit Profile</h2>
                <form action="update_profile.php" method="POST">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    
                    <button type="button" onclick="confirmSubmit1(event, 'Are you sure you want to change your profile?')">Save Changes</button><br>
                </form>
                <button onclick="cancelEdit()">Cancel</button>
            </div>
            <!-- Change Password Section -->
            <div class="account-info">
                <br><h2>Change Password</h2><br>
                <form action="change_password.php" method="POST">
                    <label for="current-password">Current Password:</label>
                    <input type="password" id="current-password" name="current-password" required>

                    <label for="new-password">New Password:</label>
                    <input type="password" id="new-password" name="new-password" required>

                    <label for="confirm-password">Confirm New Password:</label>
                    <input type="password" id="confirm-password" name="confirm-password" required>

                    <button type="button" onclick="confirmSubmit(event, 'Are you sure you want to change your password?')">Change Password</button>
                </form>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2024 E-Blotter System. All rights reserved.</p>
    </div>
</div>
<script src= "JS/account.js"></script>
</body>
</html>