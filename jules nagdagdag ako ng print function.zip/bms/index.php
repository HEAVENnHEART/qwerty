<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Blotter Public Portal</title>
    <link rel="stylesheet" href="CSS/index.css">
    <link rel="stylesheet" href="CSS/style.css">

</head>
<body>
    <nav class="navbar">
        <div class="logo">Lawa Public Portal</div>
        <ul class="nav-links">
            <li><a href="#home">Home</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="#request">Request</a></li>
            <?php if(isset($_SESSION['user'])): ?>
    <li class="user-menu">
        <a href="#" class="user-trigger">
            <img src="IMG/placeholderuser.png" alt="User" class="user-avatar">
            <?php echo htmlspecialchars($_SESSION['user']['username']); ?>
        </a>
        <ul class="index-dropdown-menu">
            <li><a href="profile.php">Profile</a></li>
            <li><a href="track-documents.php">Track Documents</a></li>
            <li><a href="logout_public.php">Logout</a></li>
        </ul>
    </li>
<?php else: ?>
    <li><a href="#" onclick="openLoginModal()">Login</a></li>
<?php endif; ?>
        </ul>
    </nav>
    

    <main>
        <section id="home" class="hero">
            <h1>Welcome to Lawa Management System</h1>
            <p>NAG KAON KANA LAV</p>
            <button class="cta-button">Learn More</button>
        </section>

        <section id="services">
            <h2>Our Services</h2>
            <p>POGI SI AERON</p>
        </section>

        <section id="about">
            <h2>About Us</h2>
            <p>MAS POGI SI AERON</p>
        </section>

        <section id="contact">
            <h2>Contact Us</h2>
            <p>SOBRANG POGI NI AERON</p>
        </section>

        <section id="request" class="request-section">
            <div class="request-container">
                <h2>Document Request Form</h2>
                <form class="request-form" action="process_request.php" method="POST">
                    <div class="form-group">
                        <label for="fullname">Full Name</label>
                        <input type="text" id="fullname" name="fullname" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Contact Number</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="document_type">Document Type</label>
                        <select id="document_type" name="document_type" required>
                            <option value="">Select Document Type</option>
                            <option value="barangay_clearance">Barangay Clearance</option>
                            <option value="indigency">Indigency</option>
                            <option value="business_permit">Business Permit</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="purpose">Purpose</label>
                        <textarea id="purpose" name="purpose" required></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">Submit Request</button>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2024 E-Blotter System. All rights reserved.</p>
    </footer>
    <div id="loginModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div class="login-container">
            <h2>Login</h2>
            <form action="public_login.php" method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" required>
                </div>
                <button type="submit">Login</button>
                <p>Don't have an account? <a href="#" onclick="openSignupModal()">Sign up</a></p>
            </form>
        </div>
    </div>
</div>

<div id="signupModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div class="signup-container">
            <h2>Sign Up</h2>
            <form action="public_register.php" method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" name="confirm_password" required>
                </div>
                <button type="submit">Sign Up</button>
            </form>
        </div>
    </div>
</div>
<script src="JS/modal.js"></script>
</body>
</html>
