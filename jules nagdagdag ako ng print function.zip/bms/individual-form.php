<?php
include 'db.php';

$successMessage = '';  // Variable to store success message

// Start the session and check if user is logged in
session_start();
if (!isset($_SESSION['user_id'])) {
    // If no session, redirect to login page
    header("Location: index.php");
    exit(); // Stop further execution
}

// Fetch the user's information based on the user_id stored in the session
$user_id = $_SESSION['user_id']; // Get the user ID from the session
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // Get user info
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $name = trim($_POST['name']);
    $contact = trim($_POST['contact']);
    $age = trim($_POST['age']); 
    $gender = trim($_POST['gender']); 
    $relationship = trim($_POST['relationship']); 
    $address = trim($_POST['address']); // Get address value
    $time = trim($_POST['time']); // Get time value
    $case = trim($_POST['case']); // Get case value
    $description = trim($_POST['description']); // Get description value
    $position = trim($_POST['position']); // Get position value
    
    // Validate required fields
    if (empty($name) || empty($contact) || empty($age) || empty($gender) || empty($relationship) || empty($address) || empty($time) || empty($case) || empty($description) || empty($position)) {
        echo "All required fields must be filled out.";
        exit();
    }

    // Validate age (should be a number)
    if (!is_numeric($age) || $age <= 0) {
        echo "Please enter a valid age.";
        exit();
    }

    // Validate contact number (basic validation)
    if (!preg_match('/^\d{11}$/', $contact)) {
        echo "Please enter a valid 11 digit contact number.";
        exit();
    }

    // Validate the date
    $month = trim($_POST['month']);
    $day = trim($_POST['day']);
    $year = trim($_POST['year']);

    if (empty($month) || empty($day) || empty($year) || !is_numeric($day) || !is_numeric($year) || $day <= 0 || $year <= 0) {
        echo "Please enter a valid date.";
        exit();
    }

    // Insert record into `records` table
    try {
        $stmt = $pdo->prepare("INSERT INTO records (name, age, gender, relationship, contact, month, day, year, time, address, case_type, description, position) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $age, $gender, $relationship, $contact, $month, $day, $year, $time, $address, $case, $description, $position]);

        // Insert involved parties
        $recordId = $pdo->lastInsertId();  // Get the ID of the inserted record
        if (!empty($_POST['party_name'])) {
            foreach ($_POST['party_name'] as $index => $partyName) {
                if (!empty($partyName)) {
                    // Collect additional information for involved parties
                    $partyAge = $_POST['party_age'][$index]; // Get age for this party
                    $partyGender = $_POST['party_gender'][$index]; // Get gender for this party
                    $partyAddress = $_POST['party_address'][$index]; // Get address for this party
                    
                    $stmt = $pdo->prepare("INSERT INTO involved_parties (record_id, name, age, gender, address) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$recordId, $partyName, $partyAge, $partyGender, $partyAddress]);
                }
            }
        }

        // Set success message
        $successMessage = 'Blotter is added successfully';
        
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BLotter Form</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/individual-form.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="home.php">
                    <img src="logo.png" alt="E-Blotter Logo" class="logo-image">
                </a>
            </div>

            <!-- Display the logged-in user's name in the sidebar -->
            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>

            <ul>
    <li><a href="home.php">Home</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="form.php">Forms</a></li>
            <li><a href="record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document-request.php">Request</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="logout_admin.php">Log Out</a></li>
</ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Individual Form</h1>
            </div>
            <div class="container">
                <!-- Success Notification -->
                <?php if ($successMessage): ?>
                    <div class="notification" id="notification"><?= htmlspecialchars($successMessage) ?></div>
                <?php endif; ?>

                <form id="recordForm" method="POST" action="">
    <h3>Complainant</h3>

    <label for="name">Name:</label>
    <input type="text" id="name" name="name" placeholder="Name" pattern="[A-Za-z\s]+" title="Name must only contain letters and spaces" required>

    <div class="form-row">
        <div class="form-field">
            <label for="age">Age:</label>
            <input type="text" id="age" name="age" placeholder="Age" pattern="\d+" title="Age must be a number" required>
        </div>

        <div class="form-field">
            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>

        <div class="form-field">
            <label for="relationship">Relationship:</label>
            <input type="text" id="relationship" name="relationship" placeholder="Relationship" pattern="[A-Za-z\s]+" title="Relationship must only contain letters and spaces" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-field">
            <label for="contact">Contact Number:</label>
            <input type="text" id="contact" name="contact" placeholder="Contact Number" pattern="\d{11}" title="Contact number must be exactly 11 digits" required>
        </div>

        <div class="form-field">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" placeholder="Address" required>
        </div>

        <div class="form-field">
            <label for="time">Time:</label>
            <input type="time" id="time" name="time" placeholder="Time" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-field">
            <label for="month">Month:</label>
            <select id="month" name="month" required>
                <option value="">Select Month</option>
                <option value="January">January</option>
                <option value="February">February</option>
                <option value="March">March</option>
                <option value="April">April</option>
                <option value="May">May</option>
                <option value="June">June</option>
                <option value="July">July</option>
                <option value="August">August</option>
                <option value="September">September</option>
                <option value="October">October</option>
                <option value="November">November</option>
                <option value="December">December</option>
            </select>
        </div>

        <div class="form-field">
            <label for="day">Day:</label>
            <input type="text" id="day" name="day" placeholder="Day" pattern="\d+" title="Day must be a valid number" required>
        </div>

        <div class="form-field">
            <label for="year">Year:</label>
            <input type="text" id="year" name="year" placeholder="Year" pattern="\d{4}" title="Year must be a 4-digit number" required>
        </div>
    </div>

    <label for="case">Case:</label>
    <input type="text" id="case" name="case" placeholder="Case" pattern="[A-Za-z\s]+" title="Case must only contain letters and spaces" required>

    <label for="description">Description:</label>
    <textarea id="description" name="description" placeholder="Description" required></textarea>

    <h3>Respondent</h3>
    <div id="involvedParties">
        <div class="party">
            <input type="text" name="party_name[]" placeholder="Involved Party Name" pattern="[A-Za-z\s]+" title="Name must only contain letters and spaces" required>
            <input type="text" name="party_age[]" placeholder="Age" pattern="\d+" title="Age must be a number" required>
            <select name="party_gender[]" required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
            <input type="text" name="party_address[]" placeholder="Address" required>
        </div>
    </div>
    <button type="button" id="addParty">Add Party</button>
    <br>

    <h3>Official</h3>
    <input type="text" id="position" name="position" placeholder="Official's Position" pattern="[A-Za-z\s]+" title="Position must only contain letters and spaces" required>

    <div class="button-container">
        <button type="submit">Submit Record</button>
    </div>
</form>

            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2024 E-Blotter System. All rights reserved.</p>
        </div>
    </div>

    <script src="JS/individual-form.js"></script>


</body>
</html>