<?php
include 'db.php';

// Start the session to access session variables
session_start();

// Check if user session is set
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $sql_users = "SELECT * FROM users WHERE id = :user_id";  // Use parameterized query to prevent SQL injection
    $stmt_users = $pdo->prepare($sql_users);
    $stmt_users->bindValue(':user_id', $user_id, PDO::PARAM_INT);
    $stmt_users->execute();

    if ($stmt_users->rowCount() > 0) {
        $user = $stmt_users->fetch(PDO::FETCH_ASSOC); // Fetch the user as an associative array
    } else {
        echo "User not found.";
        exit(); // Stop execution if user is not found
    }
} else {
    echo "Session not started. Please log in.";
    exit(); // Stop execution if session is not found
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Blotter System - Record</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/record.css">
    <link rel="stylesheet" href="CSS/sidebar.css">

</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo-section">
                <a href="home.php">
                    <img src="logo.png" alt="E-Blotter Logo" class="logo-image">
                </a>
            </div>

            <hr><br>
            <ul>
                <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
            </ul><br><hr><br>
            
            <ul>
    <li><a href="home.php">Home</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="form.php">Forms</a></li>
            <li><a href="record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document-request.php">Request</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="logout_admin.php">Log Out</a></li>
</ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Record Tables</h1>
            </div>
            <div class="button-container">
                <a href="individual-record.php">
                    <button class="blotter-button individual">Individual</button>
                </a>
                <a href="group-record.php">
                    <button class="blotter-button group">Group</button>
                </a>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>&copy; 2024 E-Blotter System. All rights reserved.</p>
        </div>
    </div>
</body>
</html>