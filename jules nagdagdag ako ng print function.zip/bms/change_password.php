<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    
    // Get user's current password hash
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    // Verify current password
    if (password_verify($current_password, $user['password'])) {
        // Hash new password
        $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Update password
        $update_stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
        if ($update_stmt->execute([$new_password_hash, $user_id])) {
            $_SESSION['message'] = 'Password updated successfully!';
        } else {
            $_SESSION['error'] = 'Failed to update password.';
        }
    } else {
        $_SESSION['error'] = 'Current password is incorrect.';
    }
    
    header('Location: account.php');
    exit();
}
?>
