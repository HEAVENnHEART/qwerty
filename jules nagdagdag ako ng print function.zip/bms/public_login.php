<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email']
        ];
        
        // Redirect based on role
        switch($user['role']) {
            // Redirect based on super admin role
            case 'admin':
                header('Location: admin/home.php');
                break;
                // Redirect based on sub admin role
            case 'sub_admin':
                header('Location: sub_admin/home.php');
                break;
            default:
                header('Location: index.php');
        }
        exit();
    } else {
        header('Location: index.php?error=invalid_credentials');
    }
}
