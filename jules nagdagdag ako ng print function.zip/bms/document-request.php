<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch the user's information based on the user_id stored in the session
$user_id = $_SESSION['user_id']; // Get the user ID from the session
try {
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC); // Get user info
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit;
}

// Fetch document requests
$stmt = $pdo->query("SELECT * FROM document_requests ORDER BY created_at DESC");
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!isset($_SESSION['user_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Handle AJAX request for printing
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM document_requests WHERE id = ?");
        $stmt->execute([$id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($request) {
            header('Content-Type: application/json');
            echo json_encode($request);
            exit();
        }
    } catch (PDOException $e) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Database error']);
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/sidebar.css">
    <link rel="stylesheet" href="CSS/document-request.css">
</head>
<body>

<div class="wrapper">
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-section">
            <a href="home.php">
                <img src="logo.png" alt="E-Blotter Logo" class="logo-image">
            </a>
        </div>

        <!-- Display the logged-in user's name in the sidebar -->
        <hr><br>
        <ul>
            <p class="username-display">Welcome, <?= isset($user['username']) ? htmlspecialchars($user['username']) : 'Guest'; ?>!</p>
        </ul><br><hr><br>

        <ul>
    <li><a href="home.php">Home</a></li>
    <li class="has-submenu">
        <a href="#" class="blotter-menu">Blotter</a>
        <ul class="submenu">
            <li><a href="form.php">Forms</a></li>
            <li><a href="record.php">Record</a></li>
        </ul>
    </li>
    <li><a href="document-request.php">Request</a></li>
    <li><a href="account.php">Account</a></li>
    <li><a href="logout_admin.php">Log Out</a></li>
</ul>

    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>Welcome to BMS!</h1>
        </div>

        <!-- Add this inside main-content div -->
<div class="container">
    <h2>Document Requests</h2>
    <table class="requests-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Document Type</th>
                <th>Purpose</th>
                <th>Status</th>
                <th>Date Requested</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?= htmlspecialchars($request['fullname']) ?></td>
                    <td><?= htmlspecialchars($request['email']) ?></td>
                    <td><?= htmlspecialchars($request['phone']) ?></td>
                    <td><?= htmlspecialchars($request['document_type']) ?></td>
                    <td><?= htmlspecialchars($request['purpose']) ?></td>
                    <td><?= htmlspecialchars($request['status']) ?></td>
                    <td><?= htmlspecialchars($request['created_at']) ?></td>
                    <td>
                        <button onclick="updateStatus(<?= $request['id'] ?>, 'approved')" class="button">Approve</button>
                        <button onclick="updateStatus(<?= $request['id'] ?>, 'rejected')" class="button">Reject</button>
                        <button onclick="printRequest(<?= $request['id'] ?>)" class="button">Print</button>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
            </div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2024 E-Blotter System. All Rights Reserved.</p>
</div>

<script src="JS/document-request.js"></script>

</body>
</html>