function showEditForm() {
    document.getElementById('edit-profile-form').style.display = 'block';
}
function cancelEdit() {
    document.getElementById('edit-profile-form').style.display = 'none';
}
// Function to confirm submission of the Edit Profile form
function confirmSubmit1(event, message) {
    if (confirm(message)) {
        // If confirmed, submit the form
        event.target.closest('form').submit();
    }
} 
// Function to confirm submission of the Change Password form
function confirmSubmit(event, message) {
    if (confirm(message)) {
        // If confirmed, submit the form
        event.target.closest('form').submit();
    }
}

function triggerProfilePicUpload() {
    document.getElementById('profilePicInput').click();
}

function handleProfilePicChange(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('currentProfilePic').src = e.target.result;
            uploadProfilePicture(file);
        };
        reader.readAsDataURL(file);
    }
}
function validatePasswordChange(event) {
    const newPassword = document.getElementById('new_password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    
    // Remove any existing validation messages
    const existingMessages = document.getElementsByClassName('validation-message');
    while(existingMessages[0]) {
        existingMessages[0].parentNode.removeChild(existingMessages[0]);
    }
    
    // Validate password match
    if (newPassword !== confirmPassword) {
        const message = document.createElement('div');
        message.className = 'validation-message';
        message.textContent = 'New passwords do not match!';
        document.getElementById('confirm_password').after(message);
        return false;
    }
    
    // Confirm before submitting
    if (confirm('Are you sure you want to change your password?')) {
        event.target.closest('form').submit();
    }
}

function uploadProfilePicture(file) {
    const formData = new FormData();
    formData.append('profile_picture', file);

    fetch('upload_profile_picture.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('currentProfilePic').src = data.path;
            alert('Profile picture updated successfully!');
        } else {
            alert('Failed to update profile picture: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while updating profile picture.');
    });
}

// Add event listener
document.getElementById('profilePicInput').addEventListener('change', handleProfilePicChange);