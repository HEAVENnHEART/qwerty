// Show the notification if there is a success message
function showNotification() {
    const notification = document.getElementById("notification");
    if (notification) {
        notification.style.display = "block";
        setTimeout(function() {
            notification.classList.add("fadeOut");
        }, 3000);
    }
}

document.getElementById("addParty").addEventListener("click", function() {
    const partyDiv = document.createElement("div");
    partyDiv.classList.add("party");
    partyDiv.innerHTML = '<input type="text" name="party_name[]" placeholder="Involved Party Name" required>' +
                        '<input type="text" name="party_age[]" placeholder="Age" required>' +
                        '<input type="text" name="party_gender[]" placeholder="Gender" required>' +
                        '<input type="text" name="party_address[]" placeholder="Address" required>' +
                        '<input type="text" name="party_relationship[]" placeholder="Relationship" required>';
    document.getElementById("involvedParties").appendChild(partyDiv);
});

// Form Validation
document.getElementById("recordForm").addEventListener("submit", function(event) {
    let isValid = true;

    // Validate complainant fields
    const name = document.getElementById("name");
    const contact = document.getElementById("contact");
    const age = document.getElementById("age");
    const gender = document.getElementById("gender");
    const relationship = document.getElementById("relationship");
    const address = document.getElementById("address");
    const time = document.getElementById("time");
    const caseType = document.getElementById("case");
    const description = document.getElementById("description");

    // Check if required fields are empty
    if (!name.value.trim() || !contact.value.trim() || !age.value.trim() || !gender.value.trim() ||
        !relationship.value.trim() || !address.value.trim() || !time.value.trim() ||
        !caseType.value.trim() || !description.value.trim()) {
        alert("Please fill all required fields in the complainant section.");
        isValid = false;
    }

    // Validate name (should only contain letters)
    if (/[^a-zA-Z\s]/.test(name.value)) {
        alert("Name should only contain letters and spaces.");
        isValid = false;
    }

    // Validate relationship (should only contain letters)
    if (/[^a-zA-Z\s]/.test(relationship.value)) {
        alert("Relationship should only contain letters and spaces.");
        isValid = false;
    }

    // Validate case (should only contain letters)
    if (/[^a-zA-Z\s]/.test(caseType.value)) {
        alert("Case should only contain letters and spaces.");
        isValid = false;
    }

    // Validate position (should only contain letters)
    const position = document.getElementById("position");
    if (/[^a-zA-Z\s]/.test(position.value)) {
        alert("Position should only contain letters and spaces.");
        isValid = false;
    }

    // Validate age (should be a number)
    if (isNaN(age.value) || age.value <= 0) {
        alert("Please enter a valid age.");
        isValid = false;
    }

    // Validate contact (basic check for a valid phone number)
    if (!/^\d{11}$/.test(contact.value)) {
        alert("Please enter a valid 11 digit contact number.");
        isValid = false;
    }

    // Validate date fields
    const month = document.getElementById("month");
    const day = document.getElementById("day");
    const year = document.getElementById("year");

    if (!month.value || !day.value.trim() || !year.value.trim() || isNaN(day.value) || isNaN(year.value) || day.value <= 0 || year.value <= 0) {
        alert("Please enter a valid date.");
        isValid = false;
    }

    // Validate each party section
    const partyNames = document.getElementsByName("party_name[]");
    const partyAges = document.getElementsByName("party_age[]");
    const partyGenders = document.getElementsByName("party_gender[]");
    const partyAddresses = document.getElementsByName("party_address[]");

    for (let i = 0; i < partyNames.length; i++) {
        if (!partyNames[i].value.trim() || !partyAges[i].value.trim() || !partyGenders[i].value.trim() || !partyAddresses[i].value.trim()) {
            alert("Please fill all fields for each involved party.");
            isValid = false;
        }

        // Validate party name (should only contain letters)
        if (/[^a-zA-Z\s]/.test(partyNames[i].value)) {
            alert("Involved Party Name should only contain letters and spaces.");
            isValid = false;
        }

        // Validate party age (should be a number)
        if (isNaN(partyAges[i].value) || partyAges[i].value <= 0) {
            alert("Please enter a valid age for involved parties.");
            isValid = false;
        }
    }

    // Prevent form submission if any field is invalid
    if (!isValid) {
        event.preventDefault();
    }
});

// Call showNotification when the DOM is loaded
document.addEventListener('DOMContentLoaded', showNotification);
