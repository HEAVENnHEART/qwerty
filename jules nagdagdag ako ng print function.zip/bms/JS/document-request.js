function updateStatus(requestId, status) {
    if (confirm('Are you sure you want to ' + status + ' this request?')) {
        fetch('update_request_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + requestId + '&status=' + status
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Error updating status: ' + data.message);
            }
        });
    }
}

function printRequest(id) {
    fetch(`document-request.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            const printContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Barangay Document Request #${id}</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        #content { width: 80%; margin: 0 auto; padding: 20px; }
                        h1 { text-align: center; margin-bottom: 20px; }
                        .section { margin-bottom: 20px; }
                        .section h3 { margin-bottom: 10px; font-size: 18px; text-decoration: underline; }
                        .section p { margin: 5px 0; }
                        .signature-section { 
                            margin-top: 100px;
                            display: flex;
                            justify-content: space-between;
                        }
                        .signature-box {
                            text-align: center;
                            width: 200px;
                        }
                        .signature-line {
                            border-top: 1px solid black;
                            margin-top: 50px;
                        }
                        @media print { @page { margin: 2cm; } }
                    </style>
                </head>
                <body>
                    <div id="content">
                        <h1>Barangay Document Request</h1>
                        
                        <div class="section">
                            <h3>Personal Information</h3>
                            <p><strong>Full Name:</strong> ${data.fullname}</p>
                            <p><strong>Email:</strong> ${data.email}</p>
                            <p><strong>Contact Number:</strong> ${data.phone}</p>
                        </div>

                        <div class="section">
                            <h3>Request Details</h3>
                            <p><strong>Document Type:</strong> ${data.document_type}</p>
                            <p><strong>Purpose:</strong> ${data.purpose}</p>
                            <p><strong>Status:</strong> ${data.status}</p>
                            <p><strong>Date Requested:</strong> ${data.created_at}</p>
                        </div>

                        <div class="section">
                            <h3>Barangay Information</h3>
                            <p><strong>Barangay:</strong> Lawa</p>
                            <p><strong>Barangay Captain:</strong> Hon. Juan Dela Cruz</p>
                        </div>

                        <div class="signature-section">
                            <div class="signature-box">
                                <div class="signature-line">
                                    <p>Applicant's Signature</p>
                                </div>
                            </div>
                            <div class="signature-box">
                                <div class="signature-line">
                                    <p>Barangay Captain's Signature</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <script>
                        window.onload = function() { window.print(); }
                    </script>
                </body>
                </html>
            `;

            // Store original content
            const originalContent = document.body.innerHTML;
            
            // Set print content
            document.body.innerHTML = printContent;
            
            // Print and restore
            window.onafterprint = function() {
                document.body.innerHTML = originalContent;
                location.reload();
            };
            
            window.print();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error loading request data');
        });
}